# OJeovanny Studios — Patch de Performance v2
## Para o projetor HY320 e outros dispositivos Android com pouca RAM

---

## O que estava causando lentidão

O problema não era a home em si — era a **vinheta** carregada pelo plugin no boot do app, mais
algumas operações pesadas que aconteciam **todo frame** na animação:

| Problema (v1) | Custo |
|---|---|
| 600 pixels de ruído aleatório **por frame** (`fillRect` em loop) | ~2ms de CPU/frame |
| 350 estrelas de warp cada uma com `createLinearGradient` + `createRadialGradient` | ~8ms de CPU/frame |
| 4 canvas sobrepostos em full resolution | 4× memória de GPU |
| `setInterval(100ms)` aguardando o player | polling constante |
| `AudioContext` com buffer de ruído (5s × sampleRate) na inicialização | ~50MB de RAM |
| `filter: blur(Npx)` via canvas (software rendering no Android) | trava em 1GB |

Em um celular moderno isso some. No HY320 (1GB RAM, Android 9, GPU básica) cada frame levava ~16ms
e quando o JS de carregamento da biblioteca também estava rodando, a UI travava.

---

## O que o patch faz

### `plugin.js` (substitui o original)

**Detecção automática de hardware fraco:**
```
navigator.deviceMemory ≤ 1 GB  → modo lite
navigator.hardwareConcurrency ≤ 2 núcleos  → modo lite
Android versão ≤ 9  → modo lite
```

**Modo LITE (projetor/TVBox fraca):**
- 1 canvas em vez de 4 (memória de GPU ÷4)
- 80 estrelas em vez de 350
- Sem `createLinearGradient` por estrela — cor sólida direta
- Sem `filter: blur()` no canvas — Android renderiza em software, trava
- Sem ruído aleatório por frame
- Sem AudioContext (economiza ~50MB de RAM)
- Duração da vinheta: 6s em vez de 10.8s
- `MutationObserver` em vez de `setInterval` — zero CPU enquanto espera o player

**Modo FULL (PC / celular bom) — idêntico à v1, mais:**
- Ruído de filme pré-gerado em offscreen canvas, atualizado a cada 8 frames
- `will-change: transform` no overlay (layer de compositor)

### `perf-additions.scss` (adicionar ao dark/theme.scss)

- Remove escala de hover dos cards em dispositivos de pointer grosseiro (TV remoto, toque)
- Remove `backdrop-filter` do header em modo coarse (GPU-heavy)
- `will-change: transform` no `<video>` e containers de scroll
- Sem animação contínua do backdrop em hardware fraco

---

## Como aplicar

### 1. Substituir o plugin

```bash
# Na raiz do seu fork (jellyfin-web)
cp plugin.js src/plugins/ojeovannyIntro/plugin.js
```

### 2. Adicionar o CSS de performance

Abra `src/themes/dark/theme.scss` e cole o conteúdo de `perf-additions.scss`
**no final do arquivo**, depois da última linha existente.

### 3. Build e deploy

```bash
npm run build
# copie a pasta dist/ para o servidor normalmente
```

---

## Como testar no projetor

Abra o DevTools (ou use `about:blank` com console remoto) e rode:

```js
// Simula o que a detecção automática vai ver no HY320
console.log('deviceMemory:', navigator.deviceMemory);
console.log('cores:', navigator.hardwareConcurrency);
console.log('ua:', navigator.userAgent);
```

Se quiser forçar o modo lite temporariamente pra testar no PC,
adicione `?ojlite=1` na URL e modifique a função `isWeakDevice()` no plugin:

```js
function isWeakDevice() {
    if (new URLSearchParams(location.search).get('ojlite')) return true;
    // ... resto da detecção
}
```

---

## A home preview (patch anterior) continua compatível

O arquivo `src/apps/stable/routes/home2/` do patch anterior não foi tocado.
Esse patch só mexe na vinheta e no CSS do tema.
