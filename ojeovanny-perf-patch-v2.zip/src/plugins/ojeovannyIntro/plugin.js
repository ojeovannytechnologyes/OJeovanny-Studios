import { PluginType } from 'types/plugin.ts';

/**
 * OJeovanny Studios — Intro Vinheta Plugin
 * v2 — otimizado para hardware fraco (projetores Android 1GB RAM, etc.)
 *
 * MUDANÇAS DE PERFORMANCE vs v1:
 *  - Detecção automática de hardware fraco via deviceMemory / hardwareConcurrency
 *  - Em modo "lite": 1 canvas (não 4), sem ruído aleatório por frame, 80 estrelas (não 350),
 *    sem gradiente por estrela (cor sólida), duração 6s (não 10.8s)
 *  - Pixel noise movido para offscreen canvas pré-gerado (atualiza a cada 8 frames, não todo frame)
 *  - AudioContext criado com lazy init + guard contra dispositivos sem suporte
 *  - setInterval de polling substituído por MutationObserver (zero CPU quando nada muda)
 *  - will-change: transform no overlay para promover layer no compositor do navegador
 */

// ── DETECÇÃO DE HARDWARE ──────────────────────────────────────────────────────

function isWeakDevice() {
    // navigator.deviceMemory: RAM em GB (Chrome/Android). Ausente em Firefox/Safari → assume OK
    const mem = navigator.deviceMemory;          // undefined | 0.25 | 0.5 | 1 | 2 | 4 | 8
    if (mem !== undefined && mem <= 1) return true;

    // navigator.hardwareConcurrency: nº de núcleos lógicos
    const cores = navigator.hardwareConcurrency; // undefined em browsers antigos → 0
    if (cores && cores <= 2) return true;

    // User-agent com "Android" + versão ≤ 9 — boa heurística para TVBoxes antigas
    const ua = navigator.userAgent;
    const androidVer = ua.match(/Android\s+(\d+)/i);
    if (androidVer && parseInt(androidVer[1], 10) <= 9) return true;

    return false;
}

const LITE_MODE = isWeakDevice();

// ── PLUGIN ────────────────────────────────────────────────────────────────────

class OJeovannyIntroPlugin {
    constructor() {
        this.name = 'OJeovanny Studios Intro';
        this.type = PluginType.PreplayIntercept;
        this.id = 'ojeovannyintro';
        this.order = 0;
    }

    intercept(options) {
        if (options.mediaType !== 'Video') return Promise.resolve();

        return new Promise((resolve) => {
            resolve();
            scheduleIntro();
        });
    }
}

// ── INTERCEPÇÃO DO PLAYER ─────────────────────────────────────────────────────

function scheduleIntro() {
    let intercepted = false;
    let observer = null;
    let fallbackTimer = null;

    function onVideoFound(video) {
        if (intercepted) return;

        function onPlaying() {
            if (intercepted) return;
            intercepted = true;
            video.removeEventListener('playing', onPlaying);
            if (observer) { observer.disconnect(); observer = null; }
            if (fallbackTimer) { clearTimeout(fallbackTimer); fallbackTimer = null; }

            video.pause();
            showIntro(() => {
                try { video.play(); } catch (e) { /* silencioso */ }
            });
        }

        video.addEventListener('playing', onPlaying);

        if (!video.paused && !video.ended && video.readyState >= 3) {
            onPlaying();
        }
    }

    // Usa MutationObserver em vez de setInterval — zero custo quando nada muda no DOM
    const existing = document.querySelector('video');
    if (existing) {
        onVideoFound(existing);
        return;
    }

    observer = new MutationObserver(() => {
        const video = document.querySelector('video');
        if (video) {
            observer.disconnect();
            observer = null;
            onVideoFound(video);
        }
    });
    observer.observe(document.body, { childList: true, subtree: true });

    // Segurança: desiste depois de 15s
    fallbackTimer = setTimeout(() => {
        if (!intercepted && observer) {
            observer.disconnect();
            observer = null;
        }
    }, 15000);
}

// ── VINHETA ───────────────────────────────────────────────────────────────────

function showIntro(onUnpause) {
    const TOTAL_MS    = LITE_MODE ? 6000  : 10800;
    const UNPAUSE_MS  = LITE_MODE ? 400   : 500;
    const FADE_MS     = LITE_MODE ? 600   : 1200;
    const STAR_COUNT  = LITE_MODE ? 80    : 350;
    const NOISE_EVERY = LITE_MODE ? 0     : 8;  // 0 = desativa ruído

    // ── OVERLAY ──
    const overlay = document.createElement('div');
    overlay.id = 'oj-intro-overlay';
    overlay.style.cssText = `
        position:fixed;top:0;left:0;width:100vw;height:100vh;
        background:#000;z-index:99999;overflow:hidden;cursor:pointer;
        opacity:1;transition:opacity ${FADE_MS}ms ease;
        will-change:transform;
    `;

    // Em modo lite usamos 1 canvas; caso contrário 4 (bg, warp, logo, orbitals)
    const NUM_CANVAS = LITE_MODE ? 1 : 4;
    const canvases = [];
    const ctxs     = [];
    for (let i = 0; i < NUM_CANVAS; i++) {
        const c = document.createElement('canvas');
        c.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;';
        overlay.appendChild(c);
        canvases.push(c);
        ctxs.push(c.getContext('2d'));
    }

    // Atalho: no lite mode tudo vai pro mesmo contexto
    const x0 = ctxs[0];
    const x1 = LITE_MODE ? ctxs[0] : ctxs[1];
    const x2 = LITE_MODE ? ctxs[0] : ctxs[2];
    const x3 = LITE_MODE ? ctxs[0] : ctxs[3];

    // ── UI TEXT ──
    const ui = document.createElement('div');
    ui.style.cssText = 'position:absolute;top:50%;left:50%;transform:translateX(-50%);text-align:center;z-index:10;pointer-events:none;width:90vw;';

    const nameEl = document.createElement('div');
    nameEl.style.cssText = 'text-align:center;opacity:0;margin-top:clamp(90px,26vmin,230px);pointer-events:none;';

    const nameMain = document.createElement('div');
    nameMain.style.cssText = "font-family:'Cormorant Garamond','Playfair Display','Didot',Georgia,serif;font-size:clamp(22px,4.2vw,58px);letter-spacing:clamp(10px,3.5vw,40px);color:#fff;text-transform:uppercase;font-weight:300;line-height:1;";
    nameMain.textContent = 'OJeovanny';

    const nameStudios = document.createElement('div');
    nameStudios.style.cssText = "font-family:'Cormorant Garamond','Playfair Display',Georgia,serif;font-size:clamp(7px,0.9vw,12px);letter-spacing:clamp(8px,3vw,28px);color:rgba(255,255,255,0.35);text-transform:uppercase;font-weight:300;margin-top:10px;opacity:0;";
    nameStudios.textContent = 'Studios';

    const taglineEl = document.createElement('div');
    taglineEl.style.cssText = "font-family:'Cormorant Garamond','Playfair Display',Georgia,serif;font-size:clamp(7px,0.9vw,11px);letter-spacing:clamp(4px,1.5vw,13px);color:rgba(255,255,255,0.3);text-transform:uppercase;opacity:0;margin-top:8px;";
    taglineEl.textContent = 'Where Stories Come to Life';

    nameEl.appendChild(nameMain);
    nameEl.appendChild(nameStudios);
    nameEl.appendChild(taglineEl);
    ui.appendChild(nameEl);
    overlay.appendChild(ui);
    document.body.appendChild(overlay);

    // ── ESTADO ──
    let W = 0, H = 0, T0 = 0, frameN = 0, raf = null;
    let finished = false, unpauseCalled = false;

    const cl = (v, a, b) => Math.max(a, Math.min(b, v));
    const eo = (t, p = 3) => 1 - Math.pow(1 - cl(t, 0, 1), p);
    const es = t => 0.5 - 0.5 * Math.cos(cl(t, 0, 1) * Math.PI);
    const lp = (a, b, t) => a + (b - a) * t;

    // ── NOISE OFFSCREEN (só no modo full) ──
    // Pré-renderiza o ruído de filme num canvas offscreen e re-usa por N frames
    let noiseCanvas = null, noiseCtx = null, noiseFrame = 0;
    if (!LITE_MODE) {
        noiseCanvas = document.createElement('canvas');
        noiseCtx    = noiseCanvas.getContext('2d');
    }
    function updateNoise(w, h) {
        if (!noiseCanvas) return;
        noiseCanvas.width = w; noiseCanvas.height = h;
        const id = noiseCtx.createImageData(w, h);
        const d  = id.data;
        // apenas ~40% dos pixels (random skip) para ser mais rápido
        for (let i = 0; i < d.length; i += 4) {
            if (Math.random() > 0.4) continue;
            const v = Math.random() * 12 | 0;
            d[i] = d[i+1] = d[i+2] = v; d[i+3] = 255;
        }
        noiseCtx.putImageData(id, 0, 0);
    }

    // ── WARP STARS ──
    let warpStars = [];
    function makeWarpStar(forceClose) {
        const angle  = Math.random() * Math.PI * 2;
        const startD = forceClose ? Math.random() * 0.02 : Math.random() * 0.08;
        return { angle, d: startD, speed: Math.random() * 0.012 + 0.004, size: Math.random() * 1.8 + 0.4, bright: Math.random() * 0.7 + 0.3, tail: 0, born: Math.random() * 0.6 };
    }
    function initWarp() {
        warpStars = [];
        for (let i = 0; i < STAR_COUNT; i++) warpStars.push(makeWarpStar());
    }

    // ── ORBITAL RINGS (só full) ──
    const ringDefs = [
        { r: 0.22, speed: 0.0004, dashes: 24, w: 0.7, op: 0.55, tickLen: 6 },
        { r: 0.32, speed: -0.0003, dashes: 48, w: 0.5, op: 0.35, tickLen: 4 },
        { r: 0.40, speed: 0.00015, dashes: 8,  w: 0.9, op: 0.65, tickLen: 10 },
    ];
    let ringPhases = [0, 0, 0];
    const orbitDots = [];
    if (!LITE_MODE) {
        for (let i = 0; i < 6; i++) {
            orbitDots.push({ ring: i % 3, angle: Math.random() * Math.PI * 2, speed: ringDefs[i % 3].speed * (1 + (Math.random() - 0.5) * 0.4) * (Math.random() < 0.5 ? 1 : -1), sz: Math.random() * 2.5 + 1.2, ph: Math.random() * Math.PI * 2, freq: 0.02 + Math.random() * 0.01 });
        }
    }

    function warpSpeed(e) {
        if (e < 1500) return eo(e / 1500, 2);
        if (e < 3200) return 1.0;
        if (e < 5000) return lp(1.0, 0.0, eo((e - 3200) / 1800, 2));
        return 0;
    }
    function warpIntensity(e) {
        if (e < 5200) return cl(e < 200 ? 0 : 1, 0, 1);
        return eo(1 - cl((e - 5200) / 600, 0, 1));
    }

    // ── DRAW BG ──
    function drawBg(e) {
        if (LITE_MODE) {
            // Fundo simples: preto com vinheta radial — sem ruído aleatório por frame
            x0.fillStyle = '#000';
            x0.fillRect(0, 0, W, H);
            const vig = x0.createRadialGradient(W/2, H/2, H * 0.1, W/2, H/2, H * 0.8);
            vig.addColorStop(0, 'rgba(0,0,0,0)');
            vig.addColorStop(1, 'rgba(0,0,0,0.92)');
            x0.fillStyle = vig;
            x0.fillRect(0, 0, W, H);
            return;
        }

        x0.fillStyle = e < 80
            ? `rgb(${Math.round((1 - e/80)*10)},${Math.round((1 - e/80)*10)},${Math.round((1 - e/80)*10)})`
            : '#000';
        x0.fillRect(0, 0, W, H);

        const wi = warpIntensity(e);
        const vig = x0.createRadialGradient(W/2, H/2, H*0.02, W/2, H/2, H * lp(0.85, 0.7, wi));
        vig.addColorStop(0, 'rgba(0,0,0,0)');
        vig.addColorStop(1, `rgba(0,0,0,${lp(0.88, 0.96, wi)})`);
        x0.fillStyle = vig;
        x0.fillRect(0, 0, W, H);

        if (e > 4200) {
            const t  = eo(cl((e - 4200) / 1800, 0, 1));
            const ft = e > 9500 ? eo(1 - cl((e - 9500) / 700, 0, 1)) : 1;
            const bl = x0.createRadialGradient(W/2, H/2, 0, W/2, H/2, Math.min(W,H) * 0.3);
            bl.addColorStop(0, `rgba(255,255,255,${0.07 * t * ft})`);
            bl.addColorStop(0.5, `rgba(255,255,255,${0.02 * t * ft})`);
            bl.addColorStop(1, 'rgba(0,0,0,0)');
            x0.fillStyle = bl;
            x0.fillRect(0, 0, W, H);
        }

        const bh = H * 0.048;
        x0.fillStyle = '#000';
        x0.fillRect(0, 0, W, bh);
        x0.fillRect(0, H - bh, W, bh);

        // Ruído: usa canvas pré-gerado, atualizado a cada NOISE_EVERY frames
        if (noiseCanvas && noiseCanvas.width === W) {
            if (frameN % NOISE_EVERY === 0) updateNoise(W, H);
            x0.save();
            x0.globalAlpha = 0.045;
            x0.drawImage(noiseCanvas, 0, 0);
            x0.restore();
        }

        // Scanline
        const sl = (frameN * 0.65) % (H - H * 0.096) + H * 0.048;
        x0.save(); x0.globalAlpha = 0.022; x0.fillStyle = '#fff';
        x0.fillRect(0, sl, W, 1.2); x0.restore();
    }

    // ── DRAW WARP ──
    function drawWarp(e) {
        if (!LITE_MODE) x1.clearRect(0, 0, W, H);
        if (e < 50) return;

        const spd = warpSpeed(e);
        const cx = W / 2, cy = H / 2;
        const maxR = Math.sqrt(W * W + H * H) * 0.52;

        warpStars.forEach(s => {
            if (e / 10000 < s.born && spd < 0.3) return;
            const vel = s.speed * (0.5 + spd * 2.5);
            s.d += vel; s.tail = vel * lp(2, 28, spd);
            if (s.d > 1.05) { Object.assign(s, makeWarpStar(true)); s.born = 0; return; }

            const r    = s.d * maxR;
            const rPrev = Math.max(0, (s.d - s.tail * 0.001 * maxR) * maxR);
            const x_   = cx + Math.cos(s.angle) * r;
            const y_   = cy + Math.sin(s.angle) * r;
            const alpha = s.bright * cl(spd * 2 + 0.2, 0.1, 1.0) * cl((s.d - 0.01) * 8, 0, 1);
            if (alpha < 0.02) return;

            x1.save(); x1.globalAlpha = alpha;

            if (LITE_MODE) {
                // Cor sólida — sem createLinearGradient por estrela (muito mais rápido)
                x1.strokeStyle = `rgba(255,255,255,${alpha})`;
                x1.lineWidth = s.size * cl(0.3 + spd * 1.5, 0.3, 2.2);
                x1.beginPath();
                x1.moveTo(cx + Math.cos(s.angle) * rPrev, cy + Math.sin(s.angle) * rPrev);
                x1.lineTo(x_, y_);
                x1.stroke();
            } else {
                const xp = cx + Math.cos(s.angle) * rPrev;
                const yp = cy + Math.sin(s.angle) * rPrev;
                const grad = x1.createLinearGradient(xp, yp, x_, y_);
                grad.addColorStop(0, 'rgba(255,255,255,0)');
                grad.addColorStop(1, 'rgba(255,255,255,1)');
                x1.strokeStyle = grad;
                x1.lineWidth = s.size * cl(0.3 + spd * 1.5, 0.3, 2.2);
                x1.beginPath(); x1.moveTo(xp, yp); x1.lineTo(x_, y_); x1.stroke();

                x1.globalAlpha = alpha * 0.9;
                const glow = x1.createRadialGradient(x_, y_, 0, x_, y_, s.size * 2);
                glow.addColorStop(0, 'rgba(255,255,255,0.9)');
                glow.addColorStop(1, 'rgba(255,255,255,0)');
                x1.fillStyle = glow;
                x1.beginPath(); x1.arc(x_, y_, s.size * 2, 0, Math.PI * 2); x1.fill();
            }

            x1.restore();
        });

        if (!LITE_MODE && spd > 0.3) {
            for (let i = 0; i < 4; i++) {
                const phase = (frameN * 0.018 + i / 4) % 1;
                const r = phase * maxR * 0.85;
                const a = cl((1 - phase) * spd * 0.35, 0, 0.3);
                if (a < 0.01) continue;
                x1.save(); x1.globalAlpha = a;
                x1.strokeStyle = 'rgba(255,255,255,0.6)'; x1.lineWidth = lp(2.5, 0.5, phase);
                x1.beginPath(); x1.arc(cx, cy, r, 0, Math.PI * 2); x1.stroke(); x1.restore();
            }
        }
    }

    // ── DRAW LOGO ──
    function drawLogo(e) {
        const logoStart = LITE_MODE ? 3000 : 5000;
        if (e < logoStart) return;
        if (!LITE_MODE) x2.clearRect(0, 0, W, H);

        const t  = eo(cl((e - logoStart) / 1200, 0, 1), 4);
        const ft = e > (TOTAL_MS * 0.88) ? eo(1 - cl((e - TOTAL_MS * 0.88) / 700, 0, 1)) : 1;
        const cx = W / 2, cy = H / 2, S = Math.min(W, H), R = S * 0.14;

        x2.save(); x2.globalAlpha = 0.18 * t * ft; x2.strokeStyle = '#fff'; x2.lineWidth = 0.7;
        x2.beginPath(); x2.arc(cx, cy, R * 1.18, 0, Math.PI * 2); x2.stroke(); x2.restore();

        const sweep = eo(cl((e - logoStart) / 900, 0, 1), 4) * Math.PI * 2;
        x2.save(); x2.globalAlpha = 0.85 * ft; x2.strokeStyle = '#fff'; x2.lineWidth = 1.5;
        x2.beginPath(); x2.arc(cx, cy, R * 1.08, -Math.PI / 2, -Math.PI / 2 + sweep); x2.stroke(); x2.restore();

        if (e > logoStart + 500) {
            const ot     = eo(cl((e - logoStart - 200) / 900, 0, 1), 4);
            const blurPx = LITE_MODE ? 0 : lp(14, 0, ot);  // sem blur em lite (caro no Android)
            const monoR  = R * 0.62;
            const fs     = R * 1.62;

            x2.save();
            x2.globalAlpha = ot * ft;
            if (!LITE_MODE) x2.filter = `blur(${blurPx}px)`;
            x2.font = `300 ${fs}px 'Cormorant Garamond','Playfair Display',Georgia,serif`;
            x2.textAlign = 'center'; x2.textBaseline = 'middle';
            if (!LITE_MODE) { x2.shadowColor = 'rgba(255,255,255,0.7)'; x2.shadowBlur = R * 0.12; }
            x2.strokeStyle = '#fff'; x2.lineWidth = 1.5;
            x2.strokeText('O', cx - R * 0.28, cy + R * 0.05);
            x2.restore();

            if (e > logoStart + 700) {
                const jt = eo(cl((e - logoStart - 700) / 800, 0, 1), 4);
                x2.save();
                x2.globalAlpha = jt * ft;
                if (!LITE_MODE) x2.filter = `blur(${lp(10, 0, jt)}px)`;
                x2.font = `300 ${R * 1.3}px 'Cormorant Garamond','Playfair Display',Georgia,serif`;
                x2.textAlign = 'center'; x2.textBaseline = 'middle';
                x2.strokeStyle = '#fff'; x2.lineWidth = 1.2;
                x2.strokeText('J', cx + R * 0.35, cy + R * 0.04);
                x2.restore();
            }
        }
    }

    // ── DRAW ORBITALS (só full) ──
    function drawOrbitals(e) {
        if (LITE_MODE) return;
        x3.clearRect(0, 0, W, H);
        if (e < 6200) return;
        const t  = eo(cl((e - 6200) / 900, 0, 1));
        const ft = e > 9200 ? eo(1 - cl((e - 9200) / 900, 0, 1)) : 1;
        const cx = W / 2, cy = H / 2, S = Math.min(W, H);

        ringPhases[0] += 0.0004; ringPhases[1] -= 0.0003; ringPhases[2] += 0.00015;

        ringDefs.forEach((rd, ri) => {
            const r = S * rd.r, circ = 2 * Math.PI * r;
            const dashL = circ / rd.dashes * 0.45, gapL = circ / rd.dashes * 0.55;
            x3.save(); x3.globalAlpha = rd.op * t * ft; x3.strokeStyle = '#fff'; x3.lineWidth = rd.w;
            x3.setLineDash([dashL, gapL]); x3.lineDashOffset = -ringPhases[ri] * r * 100;
            x3.beginPath(); x3.arc(cx, cy, r, 0, Math.PI * 2); x3.stroke();
            x3.setLineDash([]); x3.restore();

            const tc = rd.dashes * 2;
            for (let i = 0; i < tc; i++) {
                const a = (i / tc) * Math.PI * 2 + ringPhases[ri], isMaj = (i % (tc / 4) === 0);
                if (!isMaj && i % 6 !== 0) continue;
                x3.save(); x3.globalAlpha = (isMaj ? 0.55 : 0.18) * t * ft;
                x3.strokeStyle = '#fff'; x3.lineWidth = isMaj ? 0.9 : 0.4;
                x3.beginPath();
                x3.moveTo(cx + Math.cos(a) * (r - rd.tickLen * 0.5), cy + Math.sin(a) * (r - rd.tickLen * 0.5));
                x3.lineTo(cx + Math.cos(a) * (r + rd.tickLen * 0.5), cy + Math.sin(a) * (r + rd.tickLen * 0.5));
                x3.stroke(); x3.restore();
            }
        });

        orbitDots.forEach(od => {
            od.angle += od.speed; od.ph += od.freq;
            const r  = S * ringDefs[od.ring].r;
            const px = cx + Math.cos(od.angle) * r, py = cy + Math.sin(od.angle) * r;
            const pulse = 0.6 + 0.4 * Math.sin(od.ph), a = 0.85 * t * ft * pulse;
            x3.save(); x3.globalAlpha = a;
            const dg = x3.createRadialGradient(px, py, 0, px, py, od.sz * 3);
            dg.addColorStop(0, 'rgba(255,255,255,0.95)'); dg.addColorStop(1, 'rgba(255,255,255,0)');
            x3.fillStyle = dg; x3.beginPath(); x3.arc(px, py, od.sz * 3, 0, Math.PI * 2); x3.fill();
            x3.globalAlpha = a * 0.9; x3.fillStyle = '#fff';
            x3.beginPath(); x3.arc(px, py, od.sz * 0.6, 0, Math.PI * 2); x3.fill(); x3.restore();
        });
    }

    // ── ANIMA UI TEXT ──
    function animUI(e) {
        const uiStart = LITE_MODE ? 3800 : 6800;
        const ft = e > (TOTAL_MS * 0.88) ? eo(1 - cl((e - TOTAL_MS * 0.88) / 700, 0, 1)) : 1;
        if (e < uiStart) {
            nameEl.style.opacity = 0;
        } else {
            const tm = eo(cl((e - uiStart) / 900, 0, 1));
            const isWide  = window.innerWidth > 600;
            const lsFrom  = isWide ? 60 : 32, lsTo = isWide ? 36 : 16;
            nameEl.style.opacity      = tm * ft;
            nameEl.style.letterSpacing = `${lp(lsFrom, lsTo, tm)}px`;
            if (!LITE_MODE) nameEl.style.textShadow = `0 0 ${lp(30, 4, tm)}px rgba(255,255,255,${lp(0.7, 0.12, tm)})`;

            const ts2 = eo(cl((e - uiStart - 400) / 700, 0, 1));
            nameStudios.style.opacity = ts2 * ft;
        }
        const tagStart = LITE_MODE ? 4600 : 8000;
        taglineEl.style.opacity = e < tagStart ? 0 : es(cl((e - tagStart) / 700, 0, 1)) * ft;
    }

    // ── ÁUDIO (lazy, com guard) ──
    let audioCtx = null, audioNodes = [];
    function stopAudio() {
        audioNodes.forEach(n => { try { n.stop && n.stop(); n.disconnect && n.disconnect(); } catch (err) { } });
        audioNodes = [];
        if (audioCtx) { try { audioCtx.close(); } catch (e) { } audioCtx = null; }
    }
    function playIntroAudio() {
        if (LITE_MODE) return; // Audio WebAPI é pesado em aparelhos 1GB — pula
        try {
            const AC = window.AudioContext || window.webkitAudioContext;
            if (!AC) return;
            audioCtx = new AC();
            const ac = audioCtx;

            const master = ac.createGain();
            master.gain.setValueAtTime(0, ac.currentTime);
            master.gain.linearRampToValueAtTime(0.7, ac.currentTime + 1.2);
            master.connect(ac.destination);

            const whooshBuf = ac.createBuffer(1, ac.sampleRate * 5, ac.sampleRate);
            const wd = whooshBuf.getChannelData(0);
            for (let i = 0; i < wd.length; i++) wd[i] = (Math.random() * 2 - 1);
            const whoosh  = ac.createBufferSource(); whoosh.buffer = whooshBuf;
            const wFilter = ac.createBiquadFilter(); wFilter.type = 'bandpass';
            wFilter.frequency.setValueAtTime(200, ac.currentTime);
            wFilter.frequency.linearRampToValueAtTime(2800, ac.currentTime + 2.5);
            wFilter.frequency.linearRampToValueAtTime(400,  ac.currentTime + 5);
            wFilter.Q.value = 1.2;
            const wGain = ac.createGain();
            wGain.gain.setValueAtTime(0, ac.currentTime);
            wGain.gain.linearRampToValueAtTime(0.55, ac.currentTime + 0.4);
            wGain.gain.linearRampToValueAtTime(0, ac.currentTime + 5.2);
            whoosh.connect(wFilter); wFilter.connect(wGain); wGain.connect(master);
            whoosh.start(ac.currentTime); audioNodes.push(whoosh);

            [55, 110, 165].forEach((freq, i) => {
                const osc = ac.createOscillator(); osc.type = 'sine'; osc.frequency.value = freq;
                const g = ac.createGain();
                g.gain.setValueAtTime(0, ac.currentTime);
                g.gain.linearRampToValueAtTime([0.18, 0.08, 0.04][i], ac.currentTime + 2);
                g.gain.linearRampToValueAtTime([0.22, 0.10, 0.05][i], ac.currentTime + 5);
                g.gain.linearRampToValueAtTime(0, ac.currentTime + 10.5);
                osc.connect(g); g.connect(master); osc.start(ac.currentTime); osc.stop(ac.currentTime + 11);
                audioNodes.push(osc);
            });

            const impactT = ac.currentTime + 5.2;
            [80, 160, 320].forEach((freq, i) => {
                const osc = ac.createOscillator(); osc.type = i === 0 ? 'sine' : 'triangle';
                osc.frequency.setValueAtTime(freq * 1.4, impactT);
                osc.frequency.exponentialRampToValueAtTime(freq * 0.7, impactT + 0.6);
                const g = ac.createGain();
                g.gain.setValueAtTime(0, impactT - 0.01);
                g.gain.linearRampToValueAtTime([0.5, 0.2, 0.08][i], impactT + 0.04);
                g.gain.exponentialRampToValueAtTime(0.001, impactT + 2.2);
                osc.connect(g); g.connect(master); osc.start(impactT); osc.stop(impactT + 2.5);
                audioNodes.push(osc);
            });

            const padT = ac.currentTime + 6.8;
            [220, 277, 330, 415].forEach((freq, i) => {
                const osc = ac.createOscillator(); osc.type = 'sine'; osc.frequency.value = freq;
                const lfo = ac.createOscillator(); lfo.frequency.value = 0.4 + i * 0.1;
                const lfoG = ac.createGain(); lfoG.gain.value = 0.8;
                lfo.connect(lfoG); lfoG.connect(osc.frequency);
                const g = ac.createGain();
                g.gain.setValueAtTime(0, padT);
                g.gain.linearRampToValueAtTime([0.12, 0.09, 0.07, 0.05][i], padT + 1.5);
                g.gain.linearRampToValueAtTime(0, padT + 5);
                osc.connect(g); g.connect(master); osc.start(padT); lfo.start(padT);
                osc.stop(padT + 5.5); lfo.stop(padT + 5.5); audioNodes.push(osc, lfo);
            });

            const shimT   = ac.currentTime + 7.2;
            const shimBuf = ac.createBuffer(1, ac.sampleRate * 4, ac.sampleRate);
            const sd = shimBuf.getChannelData(0);
            for (let i = 0; i < sd.length; i++) sd[i] = (Math.random() * 2 - 1);
            const shim    = ac.createBufferSource(); shim.buffer = shimBuf;
            const sFilter = ac.createBiquadFilter(); sFilter.type = 'highpass'; sFilter.frequency.value = 5000;
            const sGain   = ac.createGain();
            sGain.gain.setValueAtTime(0, shimT);
            sGain.gain.linearRampToValueAtTime(0.06, shimT + 0.8);
            sGain.gain.linearRampToValueAtTime(0, shimT + 4);
            shim.connect(sFilter); sFilter.connect(sGain); sGain.connect(master);
            shim.start(shimT); audioNodes.push(shim);
        } catch (err) {
            console.warn('[OJeovanny Intro] Audio error:', err);
        }
    }

    // ── LOOP ──
    function resize() {
        W = overlay.offsetWidth; H = overlay.offsetHeight;
        canvases.forEach(c => { c.width = W; c.height = H; });
        if (noiseCanvas) updateNoise(W, H); // pré-gera ruído no resize
    }

    function finish() {
        if (finished) return;
        finished = true;
        if (raf) cancelAnimationFrame(raf);
        stopAudio();
        if (!unpauseCalled) { unpauseCalled = true; onUnpause(); }
        overlay.style.opacity = '0';
        setTimeout(() => { overlay.remove(); }, FADE_MS);
    }

    function tick(ts) {
        if (!T0) T0 = ts;
        const e = ts - T0;
        frameN++;

        if (LITE_MODE) {
            // No lite mode, limpamos o único canvas antes de cada frame
            x0.clearRect(0, 0, W, H);
        }

        drawBg(e);
        drawWarp(e);
        drawLogo(e);
        drawOrbitals(e);
        animUI(e);

        if (!unpauseCalled && e >= TOTAL_MS - UNPAUSE_MS) {
            unpauseCalled = true;
            onUnpause();
        }

        if (e < TOTAL_MS) {
            raf = requestAnimationFrame(tick);
        } else {
            finish();
        }
    }

    overlay.addEventListener('click', () => finish());

    resize();
    initWarp();
    playIntroAudio();
    raf = requestAnimationFrame(tick);
}

export default OJeovannyIntroPlugin;
